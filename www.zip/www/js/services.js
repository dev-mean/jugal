angular.module('dd5.services', [])

.factory('LoginSvc', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var users = [{
    id: 0,
    username: 'user1@mail.com',
    password: 'password1'
  }, {
    id: 1,
    username: 'user2@mail.com',
    password: 'password2'
  }, {
    id: 2,
   username: 'user3@mail.com',
    password: 'password3'
  }, {
    id: 3,
   username: 'user4@mail.com',
    password: 'password4'
  }, {
    id: 4,
   username: 'user5@mail.com',
    password: 'password5'
  }];

  return {
    login: function(user) {
      for (var i = 0; i < users.length; i++) {
        if (users[i].username === user.username) {
          if(users[i].password === user.password)
            return {status:1,data:users[0]};
          else
            return {status:2,data:null};
        }
        else
            return {status:3,data:null};
      }
      return {status:0,data:null};
    }
  };
});
