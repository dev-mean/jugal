angular.module('dd5.controllers', [])

.controller('LoginCtrl', function($scope,$rootScope,$state,LoginSvc) {
    $scope.loginData={};
    $scope.fLogin=function()
    {
        var result=LoginSvc.login($scope.loginData);
        if(result.status===1)
        {
            $rootScope.user=result.data;
            $state.go('tab.cardholder');
        }
        else if(result.status===2)
            alert('password not matched!!');
        else if(result.status===3)
            alert('username not matched!!');
        else
            alert('user not found!!');
    }
})
.controller('CardHolderCtrl', function($scope,$rootScope,$state) {
    if($rootScope.user===undefined)
        $state.go('login');
})
.controller('MessagesCtrl', function($scope,$rootScope,$state) {
    if($rootScope.user===undefined)
        $state.go('login');
})
.controller('CamCtrl', function($scope,$rootScope,$state) {
    if($rootScope.user===undefined)
        $state.go('login');
})
.controller('ExchangeCtrl', function($scope,$rootScope,$state) {
    if($rootScope.user===undefined)
        $state.go('login');
})
.controller('ProfileCtrl', function($scope,$rootScope,$state) {
    if($rootScope.user===undefined)
        $state.go('login');
    $scope.fLogout=function()
    {
        $rootScope.user={};
        $state.go('login');
    }
})